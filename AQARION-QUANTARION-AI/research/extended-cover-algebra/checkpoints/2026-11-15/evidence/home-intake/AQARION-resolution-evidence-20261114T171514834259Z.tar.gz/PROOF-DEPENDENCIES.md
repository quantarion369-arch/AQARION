# AQARION assembled resolution evidence bundle

## Scope
The assembled complex is over QQ and resolves P/I_1(D5).
D1 is reconstructed from the reordered D5 entries.
D2 is the reconstructed endpoint syzygy matrix after the verified
unimodular basis bridge. D3,D4,D5 are the exported saved tail matrices.

This bundle does not claim recovery of the missing original program,
equality with an additional unspecified original ideal, novelty,
characteristic independence, or proof-assistant formalization.

## Dependency order
1. Check MANIFEST.json against the archive contents.
2. Read the complete-complex JSON for all five ordered matrices,
   the basis bridge, ring weights, and module degrees.
3. Inspect the structural certificate and its two explicit proofs.
4. Replay aq_semigroup_certificate.py.
5. Inspect the endpoint and generator-degree argument in the algebra receipt.
6. Replay aq_complex_json_replay.py.
7. Inspect and, if desired, replay the D4 rank witness.

The replay scripts expect the named JSON inputs in the user's home
directory. Running them creates new timestamped receipts.
Archive integrity checking alone does not execute these algebraic replays.

## Independent structural argument
The semigroup consists of integer points (a0,a1,a2,a3;k)
satisfying ai>=0 and ai+aj-k>=0 for all i<j.

The A,E0,E1,E2,E3 exponent columns form a unimodular lattice basis.

Generation proof:
For k<=0, use Ei powers and A^(-k).
For k=1, at most one coordinate is zero; subtract a suitable Bi.
For k>=2 with every ai positive, subtract C.
If ai=0, every other aj>=k; subtract Bi.
Each positive-k step decreases k and preserves the inequalities.
Hence the semigroup equals the cone's lattice points.

Every primitive facet functional equals 1 on kappa=(1,1,1,1;1).
Therefore the interior lattice points are exactly kappa+S.
Normal-semigroup canonical-module theory gives a Cohen-Macaulay
Gorenstein endpoint, with canonical generator scalar degree 3.
The ambient degree sum is (5,5,5,5;5), so the final shift is
(4,4,4,4;4), of scalar degree 12.

## Endpoint identification
The algebra replay checks endpoint Groebner reduction, A-saturation,
and equality after inverting A with the Laurent parametrization.
This binds the explicit endpoint ideal to the stated semigroup algebra.

## Generator-degree and middle-exactness argument
The minimal endpoint generators have shifts 3^8,4^6.
The second-map component ranks are 3,39,180 in degrees 4,5,6.
The lower degree-four columns have independent degree-five multiples.
Together with the exact syzygy identities, these establish the
low-degree minimal-generator counts 3,24,8.

There are no third-module generators below degree 6.
Gorenstein duality with final shift 12 excludes second-module
generators above degree 6. Thus the reconstructed second map
generates the entire endpoint kernel.

The invertible basis bridge transfers this result to aligned D2.
Duality gives third-module shifts 6^8,7^24,8^3.
The D3 image dimensions 8,64,277 in these degrees therefore
establish full generation; degree 9 gives the extra check 937.

Duality gives fourth-module shifts 8^6,9^8.
The D4 image dimensions 6 and 38 establish generation in those degrees
and hence full kernel generation, using the stated degree bounds.

## Final tail
D4*D5=0 is verified as a polynomial identity; D5 is nonzero.
The exact rational specialization gives rank(D4)>=13.
The nonzero polynomial kernel vector gives rank(D4)<=13.
Thus rank(D4)=13 over the fraction field.

The D5 entries have unit gcd. Over the polynomial UFD, every
polynomial vector in the one-dimensional fraction-field kernel
is therefore a polynomial multiple of D5.
Hence ker(D4)=P*D5, and D5 is injective.

## Minimality
Every nonzero differential entry has positive weighted degree.
Combined with exactness, this establishes minimality.

## Preservation limits
Hashes identify bytes, not mathematical truth or authorship.
The structural induction and theorem applications remain inspectable
mathematical arguments, not machine-formalized proofs.
No repository commit, remote backup, or publication is performed here.

## Structural certificate: stored generation proof
- Every generator satisfies ai>=0 and ai+aj-k>=0.
- For an integral feasible point with k<=0, use Ei powers and A^(-k).
- For k=1, at most one coordinate is zero; subtract a suitable Bi.
- For k>=2 with every ai>=1, subtract C; all inequalities remain valid.
- For k>=2 with ai=0, every other aj>=k; subtract Bi.
- Each positive-k step decreases k, so induction terminates.
- Hence S equals the integral points of the stated cone.
- Rational feasible points can be scaled to integral points, so the stated inequality cone equals the generator cone.
- Together with the unimodular lattice basis, this proves saturation.

## Structural certificate: stored canonical proof
- Primitive facet functionals are integral and equal 1 on kappa.
- An interior lattice point has each facet value at least 1.
- Subtracting kappa therefore produces a lattice point in the cone.
- Conversely kappa plus a cone lattice point is interior.
- Thus interior lattice points equal kappa+S.
- The normal-semigroup canonical-module theorem gives a principal canonical module, generated in scalar degree 3.
