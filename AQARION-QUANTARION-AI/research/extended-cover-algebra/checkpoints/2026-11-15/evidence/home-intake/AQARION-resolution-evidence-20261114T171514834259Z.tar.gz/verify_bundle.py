from pathlib import Path
import hashlib
import json
import sys
import tarfile

if len(sys.argv) != 2:
    raise SystemExit("Usage: python verify_bundle.py ARCHIVE.tar.gz")

archive = Path(sys.argv[1])
with tarfile.open(archive, "r:gz") as tar:
    members = tar.getmembers()
    names = [member.name for member in members]
    assert len(names) == len(set(names)), "Duplicate archive names"
    assert all(member.isfile() for member in members), "Unexpected member type"
    manifest = json.loads(tar.extractfile("MANIFEST.json").read())
    expected = manifest["files"]
    assert set(names) == set(expected) | {"MANIFEST.json"}
    for name, record in expected.items():
        raw = tar.extractfile(name).read()
        assert len(raw) == record["bytes"], name
        assert hashlib.sha256(raw).hexdigest() == record["sha256"], name
print("PASS: all archive members match the manifest.")
print("This is integrity verification, not an algebraic replay.")
